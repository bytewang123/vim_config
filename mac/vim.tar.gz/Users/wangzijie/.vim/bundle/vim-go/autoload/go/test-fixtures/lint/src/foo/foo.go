package foo

import "fmt"

func MissingFooDoc() {
	fmt.Println("missing doc")
}
